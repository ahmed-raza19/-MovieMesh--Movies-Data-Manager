class Visualizer {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        this.delayTime = 800;
    }

    // Helper: Sleep for animation
    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    // Helper: Create a basic node element
    createNode(value, label = "") {
        if (typeof soundManager !== 'undefined') soundManager.playPop();

        const node = document.createElement('div');
        node.classList.add('node', 'pop');
        node.setAttribute('data-value', value);

        // Content
        // For AVL/Graph, value might be an object, we need a string
        const text = typeof value === 'object' ? value.title : value;
        node.innerText = text ? text.substring(0, 3) : "N"; // Shorten for display

        // Tooltip
        node.title = label || text;

        this.container.appendChild(node);
        return node;
    }

    // Clear Container
    clear() {
        this.container.innerHTML = '';
        // If there's an SVG layer, preserve it or recreate it?
        // For now, simple clear.
        if (this.container.id.includes('graph')) {
            // Graph has a persistent SVG layer we might want to keep
            // Re-adding it or clearing only nodes
            this.container.innerHTML = '<svg id="graph-svg"></svg>';
        }
    }

    setPosition(element, x, y) {
        element.style.left = `${x}px`;
        element.style.top = `${y}px`;
    }

    setHighlight(node, active) {
        if (!node) return;
        if (active) node.classList.add('highlight');
        else node.classList.remove('highlight');
    }
}
