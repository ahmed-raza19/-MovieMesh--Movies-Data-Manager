class SoundManager {
    constructor() {
        this.ctx = new (window.AudioContext || window.webkitAudioContext)();
        this.enabled = true;
    }

    playOscillator(freq, type, duration) {
        if (!this.enabled) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = type;
        osc.frequency.setValueAtTime(freq, this.ctx.currentTime);

        gain.gain.setValueAtTime(0.1, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + duration);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start();
        osc.stop(this.ctx.currentTime + duration);
    }

    playClick() {
        this.playOscillator(800, 'sine', 0.1);
    }

    playInsert() {
        this.playOscillator(600, 'sine', 0.15);
        setTimeout(() => this.playOscillator(1200, 'sine', 0.3), 100);
    }

    playPop() {
        this.playOscillator(400, 'triangle', 0.1);
    }

    playSuccess() {
        this.playOscillator(500, 'sine', 0.1);
        setTimeout(() => this.playOscillator(700, 'sine', 0.1), 100);
        setTimeout(() => this.playOscillator(1000, 'sine', 0.2), 200);
    }
}

const soundManager = new SoundManager();
