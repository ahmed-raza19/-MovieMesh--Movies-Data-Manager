// Main Controller - Refactored for Manager Workflow

const app = {
    currentView: 'home',
    dataLoaded: false,

    init: () => {
        console.log("CineGraphX Initialized");
        app.setupNavigation();
        app.setupBackground();

        // Auto-load data if not already loaded
        // Simulation of "booting up" the database
        setTimeout(() => {
            app.populateDataStructures();
        }, 1000);
    },

    populateDataStructures: () => {
        if (app.dataLoaded) return;

        console.log("Populating Data Structures...");

        // Populate AVL
        MOCK_MOVIES.forEach(m => avlVisualizer.populate(m));
        avlVisualizer.renderTree(); // Render initial state (maybe too big, but we can center)

        // Populate Hash Table
        MOCK_MOVIES.forEach(m => {
            m.actors.forEach(actor => hashVisualizer.populate(actor, m));
        });
        hashVisualizer.renderTable();

        // Populate Graph
        graphVisualizer.populate(MOCK_MOVIES);

        // Populate List (just for demo, add all titles)
        MOCK_MOVIES.forEach(m => listVisualizer.populate(m.title));
        listVisualizer.renderList();

        app.dataLoaded = true;

        // Update Status
        const status = document.querySelector('.status-indicator');
        if (status) {
            status.innerHTML = '<span class="dot" style="background:var(--green)"></span> Database Online (30 Records)';
        }
    },

    setupNavigation: () => {
        const links = document.querySelectorAll('.nav-links li');
        links.forEach(link => {
            link.addEventListener('click', () => {
                const target = link.dataset.target;
                app.navigate(target);
            });
        });
    },

    navigate: (viewId) => {
        // Update Nav
        document.querySelectorAll('.nav-links li').forEach(el => el.classList.remove('active'));
        const activeLink = document.querySelector(`.nav-links li[data-target="${viewId}"]`);
        if (activeLink) activeLink.classList.add('active');

        // Update View
        document.querySelectorAll('.view').forEach(el => el.classList.remove('active'));
        document.getElementById(viewId).classList.add('active');

        app.currentView = viewId;
    },

    setupBackground: () => {
        const canvas = document.getElementById('bg-canvas');
        const ctx = canvas.getContext('2d');

        const resize = () => {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        };
        window.addEventListener('resize', resize);
        resize();

        const particles = [];
        for (let i = 0; i < 50; i++) {
            particles.push({
                x: Math.random() * canvas.width,
                y: Math.random() * canvas.height,
                vx: (Math.random() - 0.5) * 0.5,
                vy: (Math.random() - 0.5) * 0.5,
                size: Math.random() * 2,
                alpha: Math.random() * 0.5
            });
        }

        const animate = () => {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = '#ffffff';
            particles.forEach(p => {
                p.x += p.vx;
                p.y += p.vy;
                if (p.x < 0) p.x = canvas.width;
                if (p.x > canvas.width) p.x = 0;
                if (p.y < 0) p.y = canvas.height;
                if (p.y > canvas.height) p.y = 0;
                ctx.globalAlpha = p.alpha;
                ctx.beginPath();
                ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
                ctx.fill();
            });
            requestAnimationFrame(animate);
        };
        animate();
    },

    // Legacy sim method if user clicks button
    startImportSim: () => {
        const progress = document.getElementById('import-progress');
        const bar = progress.querySelector('.fill');
        const log = progress.querySelector('.log-console');
        const btn = document.querySelector('.import-simulation button');

        progress.classList.remove('hidden');
        btn.disabled = true;

        let i = 0;
        const total = MOCK_MOVIES.length;

        const interval = setInterval(() => {
            if (i >= total) {
                clearInterval(interval);
                log.innerHTML = `<span style="color:var(--primary)">SUCCESS: ${total} Movies Indexing Complete.</span>`;
                setTimeout(() => {
                    progress.classList.add('hidden');
                    btn.disabled = false;
                    app.navigate('avl'); // Go to first view
                }, 1500);
                return;
            }
            bar.style.width = `${((i + 1) / total) * 100}%`;
            log.innerText = `> Indexing: ${MOCK_MOVIES[i].title}...`;
            i++;
        }, 50);
    }
};

window.addEventListener('DOMContentLoaded', app.init);
