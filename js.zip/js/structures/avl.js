class AVLVisualizer extends Visualizer {
    constructor() {
        super('avl-canvas-container');
        this.root = null;
    }

    createTreeNode(data) {
        return {
            data: data,
            left: null,
            right: null,
            height: 1,
            ui: null
        };
    }

    getHeight(node) { return node ? node.height : 0; }
    updateHeight(node) { if (node) node.height = Math.max(this.getHeight(node.left), this.getHeight(node.right)) + 1; }
    getBalance(node) { return node ? this.getHeight(node.left) - this.getHeight(node.right) : 0; }

    // Standard Rotations (omitted detailed logic comments for brevity, logic remains same)
    rotateRight(y) {
        let x = y.left; let T2 = x.right; x.right = y; y.left = T2;
        this.updateHeight(y); this.updateHeight(x); return x;
    }
    rotateLeft(x) {
        let y = x.right; let T2 = y.left; y.left = x; x.right = T2;
        this.updateHeight(x); this.updateHeight(y); return y;
    }

    populate(data) {
        this.root = this.insertRecursive(this.root, data);
    }

    insertRecursive(node, data) {
        // Standard AVL Insert
        if (!node) return this.createTreeNode(data);
        if (data.title < node.data.title) node.left = this.insertRecursive(node.left, data);
        else if (data.title > node.data.title) node.right = this.insertRecursive(node.right, data);
        else return node;

        this.updateHeight(node);
        let balance = this.getBalance(node);
        // Balancing...
        if (balance > 1 && data.title < node.left.data.title) return this.rotateRight(node);
        if (balance < -1 && data.title > node.right.data.title) return this.rotateLeft(node);
        if (balance > 1 && data.title > node.left.data.title) { node.left = this.rotateLeft(node.left); return this.rotateRight(node); }
        if (balance < -1 && data.title < node.right.data.title) { node.right = this.rotateRight(node.right); return this.rotateLeft(node); }
        return node;
    }

    renderTree() {
        this.clear();
        if (!this.root) return;

        // Calculate Dynamic Dimensions for 5000 Nodes
        // Height ~13-15 levels. 
        // Leaf width required: 2^Height * nodeWidth. This is too big.
        // We will use a tighter layout: Reingold-Tilford-ish or just fixed large width with scroll.
        // Let's try explicit generous spacing.

        const treeHeight = this.getHeight(this.root);
        const verticalGap = 80;
        const requiredHeight = (treeHeight + 2) * verticalGap;

        // Horizontal spacing needs to be logarithmic? 
        // For simple visualization of massive trees, we just ensure no overlap at deep levels is hard.
        // We'll set a massive width and let the user scroll.

        // Dynamic Width based on approximate leaf count (5000 nodes -> ~2500 leaves)
        // 2500 leaves * 20px = 50,000px width.
        const requiredWidth = Math.max(this.container.offsetWidth, 5000 * 30);

        this.container.style.width = '100%'; // Container itself is fixed
        // We need an inner wrapper if we want native scroll, BUT "Visualizer" appends absolute nodes to container.
        // So we must expand the container's scrollable content.

        // Actually, CSS `overflow: auto` on container handles it if the children are positioned far out.
        // We just need to make sure we position them relative to a center point that allows for left/right expansion.
        // Let's start X at center of the Massive Width.

        // Hack: Create a 'ghost' element to force scrollbar breadth?
        // Or just let absolute positioning dictate scroll.
        // If we position at x=25000, we need the user to start scrolled there.
        // Better: Position Root at 50% of the computed width.

        const startX = requiredWidth / 2;
        const startY = 40;

        // Recursively draw, but scale gap by depth to prevent overlap
        // Initial gap must be large.
        const initialGap = requiredWidth / 4;

        this.drawNodeRecursive(this.root, startX, startY, initialGap, 0);

        // Scroll to center initially
        setTimeout(() => {
            this.container.scrollLeft = startX - this.container.offsetWidth / 2;
        }, 100);
    }

    drawNodeRecursive(node, x, y, gap, depth) {
        if (!node) return;

        const el = this.createNode(node.data, node.data.title);
        el.style.width = '20px';
        el.style.height = '20px';
        el.style.fontSize = '0'; // Hide text for dense tree
        el.title = `${node.data.title} (${node.data.rating})`; // Tooltip

        // Color by Rating (Heatmap)
        const hue = (node.data.rating - 4) * 20; // 4.0->0(Red), 9.0->100(Green)
        el.style.backgroundColor = `hsl(${hue}, 70%, 50%)`;
        el.style.border = 'none';

        this.setPosition(el, x, y);
        node.ui = el;

        // Draw connections
        if (node.left) {
            this.drawConnection(x, y, x - gap, y + 60);
            this.drawNodeRecursive(node.left, x - gap, y + 60, gap * 0.5, depth + 1);
        }
        if (node.right) {
            this.drawConnection(x, y, x + gap, y + 60);
            this.drawNodeRecursive(node.right, x + gap, y + 60, gap * 0.5, depth + 1);
        }
    }

    drawConnection(x1, y1, x2, y2) {
        const length = Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);
        const angle = Math.atan2(y2 - y1, x2 - x1) * 180 / Math.PI;
        const line = document.createElement('div');
        Object.assign(line.style, {
            position: 'absolute', height: '1px', backgroundColor: 'rgba(255,255,255,0.1)',
            width: `${length}px`, left: `${x1}px`, top: `${y1}px`,
            transformOrigin: '0 0', transform: `rotate(${angle}deg)`, zIndex: '1'
        });
        this.container.appendChild(line);
    }

    // VISUAL SEARCH (Case Insensitive Fix)
    async search() {
        const input = document.getElementById('avl-input');
        const val = input.value.trim().toLowerCase(); // Normalize input
        if (!val) return;

        const resultsDiv = document.getElementById('avl-results');
        if (resultsDiv) resultsDiv.classList.add('hidden');

        // Reset styles
        document.querySelectorAll('.node').forEach(n => {
            // Reset to original heatmap color? Or white?
            // Hard to store original color. Let's just reset to white for simplicity or re-render?
            // Re-render is slow. Let's just clear highlights.
            n.style.boxShadow = 'none';
            n.style.transform = 'translate(-50%,-50%) scale(1)';
            n.style.border = 'none';
        });

        const foundNode = await this.searchRecursive(this.root, val);

        if (foundNode) {
            if (typeof soundManager !== 'undefined') soundManager.playSuccess();
            // Scroll to view
            if (foundNode.ui) {
                foundNode.ui.scrollIntoView({ behavior: "smooth", block: "center", inline: "center" });
            }
        } else {
            alert(`Movie "${input.value}" not found.`);
        }
    }

    async searchRecursive(node, val) {
        if (!node) return null;

        // Highlight traversal path
        if (node.ui) {
            node.ui.style.boxShadow = '0 0 10px var(--primary)';
            if (typeof soundManager !== 'undefined') soundManager.playPop();
            await this.sleep(50); // Fast traversal
        }

        const nodeTitle = node.data.title.toLowerCase();

        if (nodeTitle === val) {
            // Match found
            if (node.ui) {
                node.ui.style.backgroundColor = 'var(--secondary)';
                node.ui.style.transform = 'translate(-50%, -50%) scale(3)';
                node.ui.style.zIndex = 100;

                // Show Overlay
                const resultsDiv = document.getElementById('avl-results');
                if (resultsDiv) {
                    resultsDiv.innerHTML = `<h3>${node.data.title}</h3>
                    <p><strong>Year:</strong> ${node.data.year}</p>
                    <p><strong>Rating:</strong> <span style="color:var(--accent)">★${node.data.rating}</span></p>
                    <p><strong>Director:</strong> ${node.data.director}</p>
                    <p><strong>Cast:</strong> ${node.data.actors.join(', ')}</p>`;
                    resultsDiv.classList.remove('hidden');
                }
            }
            return node;
        }

        if (val < nodeTitle) return await this.searchRecursive(node.left, val);
        else return await this.searchRecursive(node.right, val);
    }

    // Filter by Rating (unchanged, just works)
    filterRating() {
        const input = document.getElementById('rating-min');
        const minRating = parseFloat(input.value);
        if (isNaN(minRating)) return;

        const resultsDiv = document.getElementById('avl-results');
        resultsDiv.innerHTML = `<h3>Movies Rated > ${minRating}</h3>`;
        resultsDiv.classList.remove('hidden');

        const matches = [];
        this.collectByRating(this.root, minRating, matches);

        if (matches.length === 0) {
            resultsDiv.innerHTML += "<p>No matches found.</p>";
            return;
        }

        // Sort by rating desc
        matches.sort((a, b) => b.rating - a.rating);

        matches.slice(0, 50).forEach(m => {
            const div = document.createElement('div');
            div.className = 'result-item';
            div.innerHTML = `<strong>${m.title}</strong> <span style="float:right; color:var(--accent)">★${m.rating}</span>`;
            // Add click to locate?
            div.onclick = () => {
                document.getElementById('avl-input').value = m.title;
                this.search();
            };
            div.style.cursor = 'pointer';
            resultsDiv.appendChild(div);
        });
    }

    collectByRating(node, min, list) {
        if (!node) return;
        if (node.data.rating >= min) list.push(node.data);
        this.collectByRating(node.left, min, list);
        this.collectByRating(node.right, min, list);
    }
}

const avlVisualizer = new AVLVisualizer();
