class ListVisualizer extends Visualizer {
    constructor() {
        super('list-canvas-container');
        this.head = null;
    }

    // Populate List Visuals (just show a subset)
    populate(val) {
        // Just append to tail
        const newNode = { val: val, next: null };
        if (!this.head) {
            this.head = newNode;
        } else {
            let temp = this.head;
            while (temp.next) temp = temp.next;
            temp.next = newNode;
        }
    }

    renderList() {
        this.clear();
        let curr = this.head;
        let x = 100;
        let y = 150;
        let limit = 10; // Only show first 10 for demo to avoid overflow

        while (curr && limit > 0) {
            const node = this.createNode(curr.val, curr.val);
            node.style.width = '120px';
            node.style.fontSize = '0.7rem';

            this.setPosition(node, x, y);

            // Draw Arrow to next
            if (curr.next && limit > 1) {
                this.drawArrow(x + 60, y, x + 160 - 60, y);
            }

            x += 160;
            curr = curr.next;
            limit--;
        }
    }

    drawArrow(x1, y1, x2, y2) {
        const length = x2 - x1;
        const line = document.createElement('div');
        Object.assign(line.style, {
            position: 'absolute', height: '2px', backgroundColor: 'var(--secondary)',
            width: `${length}px`, left: `${x1}px`, top: `${y1}px`
        });

        this.container.appendChild(line);

        // Arrowhead
        const head = document.createElement('div');
        Object.assign(head.style, {
            position: 'absolute', borderTop: '5px solid transparent',
            borderBottom: '5px solid transparent', borderLeft: '10px solid var(--secondary)',
            left: `${x2}px`, top: `${y1 - 5}px`
        });
        this.container.appendChild(head);
    }
}

const listVisualizer = new ListVisualizer();
