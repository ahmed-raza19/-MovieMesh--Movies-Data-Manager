class GraphVisualizer extends Visualizer {
    constructor() {
        super('graph-canvas-container');
        this.canvas = document.getElementById('graph-canvas');
        this.ctx = this.canvas.getContext('2d');

        this.nodes = [];
        this.edges = [];
        this.adjacencyList = new Map();

        this.camera = { x: 0, y: 0, z: -1200 };
        this.rotation = { x: 0, y: 0 };
        this.focalLength = 800;

        this.isDragging = false;
        this.lastMouse = { x: 0, y: 0 };

        this.setupInteraction();
        this.resize();
        window.addEventListener('resize', () => this.resize());

        this.animate = this.animate.bind(this);
        requestAnimationFrame(this.animate);
    }

    resize() {
        if (!this.container || !this.canvas) return;
        this.canvas.width = this.container.offsetWidth;
        this.canvas.height = this.container.offsetHeight;
        this.cx = this.canvas.width / 2;
        this.cy = this.canvas.height / 2;
    }

    setupInteraction() {
        this.container.addEventListener('mousedown', (e) => {
            this.isDragging = true;
            this.lastMouse = { x: e.clientX, y: e.clientY };
            this.container.style.cursor = 'grabbing';
        });

        window.addEventListener('mousemove', (e) => {
            if (!this.isDragging) return;
            const dx = e.clientX - this.lastMouse.x;
            const dy = e.clientY - this.lastMouse.y;
            this.rotation.y += dx * 0.005;
            this.rotation.x += dy * 0.005;
            this.lastMouse = { x: e.clientX, y: e.clientY };
        });

        window.addEventListener('mouseup', () => {
            this.isDragging = false;
            this.container.style.cursor = 'grab';
        });

        this.container.addEventListener('wheel', (e) => {
            e.preventDefault();
            this.camera.z += e.deltaY * 2;
        });
    }

    populate(movies) {
        // Init 3D Nodes
        this.nodes = movies.map(m => {
            const theta = Math.random() * 2 * Math.PI;
            const phi = Math.acos(2 * Math.random() - 1);
            const r = 800 * Math.cbrt(Math.random());

            return {
                id: m.title, // Keep original Case ID
                idLower: m.title.toLowerCase(), // Cached lowercase for fast search
                data: m,
                x: r * Math.sin(phi) * Math.cos(theta),
                y: r * Math.sin(phi) * Math.sin(theta),
                z: r * Math.cos(phi),
                color: '#00f2ff',
                highlight: false,
                scale: 1
            };
        });

        this.adjacencyList.clear();
        for (let n of this.nodes) this.adjacencyList.set(n.id, []);

        // Build Actor -> Movies map
        const actorMap = {};
        this.nodes.forEach((n, idx) => {
            n.data.actors.forEach(act => {
                if (!actorMap[act]) actorMap[act] = [];
                actorMap[act].push(idx);
            });
        });
        this.actorMap = actorMap;
    }

    getNeighbors(nodeIndex) {
        const neighbors = new Set();
        const movie = this.nodes[nodeIndex].data;
        movie.actors.forEach(act => {
            const others = this.actorMap[act];
            if (others) {
                others.forEach(idx => {
                    if (idx !== nodeIndex) neighbors.add(idx);
                });
            }
        });
        return Array.from(neighbors).map(idx => this.nodes[idx]);
    }

    project(p) {
        let x = p.x; let y = p.y; let z = p.z;
        let cosY = Math.cos(this.rotation.y); let sinY = Math.sin(this.rotation.y);
        let x1 = x * cosY - z * sinY; let z1 = z * cosY + x * sinY;
        let cosX = Math.cos(this.rotation.x); let sinX = Math.sin(this.rotation.x);
        let y1 = y * cosX - z1 * sinX; let z2 = z1 * cosX + y * sinX;
        z2 -= this.camera.z;
        if (z2 <= 0) return null;
        const scale = this.focalLength / z2;
        return { x: x1 * scale + this.cx, y: y1 * scale + this.cy, scale: scale, zIndex: z2 };
    }

    animate() {
        if (app.currentView !== 'graph' || !this.ctx) {
            requestAnimationFrame(this.animate);
            return;
        }

        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

        const drawnNodes = [];
        for (let i = 0; i < this.nodes.length; i++) {
            const n = this.nodes[i];
            const p = this.project(n);
            if (p) {
                n._proj = p;
                drawnNodes.push(n);
            }
        }
        drawnNodes.sort((a, b) => b._proj.zIndex - a._proj.zIndex);

        for (let n of drawnNodes) {
            const p = n._proj;
            if (n.highlight) {
                this.ctx.beginPath();
                this.ctx.arc(p.x, p.y, 8 * p.scale, 0, Math.PI * 2);
                this.ctx.fillStyle = '#ff0055';
                this.ctx.fill();
                this.ctx.fillStyle = 'white';
                this.ctx.font = `${14 * p.scale}px sans-serif`;
                this.ctx.fillText(n.id, p.x + 10, p.y);
            } else {
                if (p.scale < 0.2) {
                    this.ctx.fillStyle = 'rgba(0, 242, 255, 0.4)';
                    this.ctx.fillRect(p.x, p.y, 2, 2);
                } else {
                    this.ctx.beginPath();
                    this.ctx.arc(p.x, p.y, 3 * p.scale, 0, Math.PI * 2);
                    this.ctx.fillStyle = n.color;
                    this.ctx.fill();
                }
            }
        }

        if (this.pathEdges) {
            this.ctx.strokeStyle = '#ff0055';
            this.ctx.lineWidth = 2;
            this.ctx.beginPath();
            for (let e of this.pathEdges) {
                if (e.source._proj && e.target._proj) {
                    this.ctx.moveTo(e.source._proj.x, e.source._proj.y);
                    this.ctx.lineTo(e.target._proj.x, e.target._proj.y);
                }
            }
            this.ctx.stroke();
        }

        requestAnimationFrame(this.animate);
    }

    async shortestPath() {
        const t1 = document.getElementById('graph-path-1').value.trim().toLowerCase();
        const t2 = document.getElementById('graph-path-2').value.trim().toLowerCase();

        if (!t1 || !t2) return;

        this.clearResults();

        // Case insensitive find
        const startIdx = this.nodes.findIndex(n => n.idLower === t1);
        const endIdx = this.nodes.findIndex(n => n.idLower === t2);

        if (startIdx === -1 || endIdx === -1) {
            let msg = "Could not find: ";
            if (startIdx === -1) msg += `"${document.getElementById('graph-path-1').value}" `;
            if (endIdx === -1) msg += `"${document.getElementById('graph-path-2').value}"`;
            alert(msg);
            return;
        }

        const startNode = this.nodes[startIdx];
        const endNode = this.nodes[endIdx];

        // Highlight Start/End immediately so user knows we found them
        startNode.highlight = true;
        endNode.highlight = true;

        const queue = [[startIdx]];
        const visited = new Set();
        visited.add(startIdx);

        let foundPathIds = null;

        while (queue.length > 0) {
            const path = queue.shift();
            const lastIdx = path[path.length - 1];

            if (lastIdx === endIdx) {
                foundPathIds = path;
                break;
            }

            if (path.length >= 6) continue;

            const neighbors = this.getNeighbors(lastIdx);
            for (let n of neighbors) {
                const nIdx = this.nodes.indexOf(n);
                if (!visited.has(nIdx)) {
                    visited.add(nIdx);
                    queue.push([...path, nIdx]);
                }
            }
        }

        if (foundPathIds) {
            const resultsPanel = document.getElementById('graph-results-panel');
            const resultsList = document.getElementById('graph-results-list');
            resultsPanel.classList.remove('hidden');

            this.pathEdges = [];

            for (let i = 0; i < foundPathIds.length; i++) {
                const n = this.nodes[foundPathIds[i]];
                n.highlight = true;

                if (i < foundPathIds.length - 1) {
                    this.pathEdges.push({ source: n, target: this.nodes[foundPathIds[i + 1]] });
                }

                // Construct logic description
                let logic = "";
                if (i < foundPathIds.length - 1) {
                    const next = this.nodes[foundPathIds[i + 1]];
                    // Why are they connected?
                    const sharedActors = n.data.actors.filter(a => next.data.actors.includes(a));
                    if (sharedActors.length > 0) logic = `Shared: ${sharedActors[0]}`;
                }

                const li = document.createElement('li');
                li.className = 'connector';
                li.innerHTML = `<strong>step ${i + 1}:</strong> ${n.id} <br><small style="color:var(--primary)">${logic}</small>`;
                resultsList.appendChild(li);

                if (typeof soundManager !== 'undefined') soundManager.playPop();
                await this.sleep(300);
            }
            if (typeof soundManager !== 'undefined') soundManager.playSuccess();
        } else {
            alert("No 6-degree connection found between these movies.");
        }
    }

    recommend() {
        this.clearResults();
        const resultsPanel = document.getElementById('graph-results-panel');
        const resultsList = document.getElementById('graph-results-list');
        resultsPanel.classList.remove('hidden');
        resultsPanel.querySelector('h3').innerText = "Recommendations";

        const recs = [];
        for (let i = 0; i < 5; i++) {
            recs.push(this.nodes[Math.floor(Math.random() * this.nodes.length)]);
        }

        recs.forEach((n, i) => {
            n.highlight = true;
            const li = document.createElement('li');
            li.innerHTML = `<strong>#${i + 1}</strong> ${n.id} <br><small>Rating: ${n.data.rating} | ${n.data.genres[0]}</small>`;
            resultsList.appendChild(li);
        });
        if (typeof soundManager !== 'undefined') soundManager.playSuccess();
    }

    clearResults() {
        this.nodes.forEach(n => n.highlight = false);
        this.pathEdges = [];
        const ul = document.getElementById('graph-results-list');
        if (ul) ul.innerHTML = '';
        const panel = document.getElementById('graph-results-panel');
        if (panel) panel.classList.add('hidden');
    }
}

const graphVisualizer = new GraphVisualizer();
