class HashVisualizer extends Visualizer {
    constructor() {
        super('hash-canvas-container');
        this.size = 19;
        this.table = new Array(this.size).fill(null);
    }

    hash(key) {
        // Normalize key for hashing to ensure case-insensitivity consistency across bucket placement?
        // Actually, if we want case-insensitive search, we should hash the LOWERCASE key.
        const normalizedKey = key.toLowerCase();
        let h = 0;
        for (let i = 0; i < normalizedKey.length; i++) {
            h = (h * 31 + normalizedKey.charCodeAt(i)) % this.size;
        }
        return h < 0 ? -h : h;
    }

    populate(key, movie) {
        // Store Key as original, but hash based on normalized?
        // Or just store normalized? Let's retain original casing for display, but index by lower.
        const idx = this.hash(key);

        let curr = this.table[idx];
        while (curr) {
            // Check match (case insensitive)
            if (curr.key.toLowerCase() === key.toLowerCase()) {
                curr.movies.push(movie);
                return;
            }
            curr = curr.next;
        }
        // New node
        const newNode = { key: key, movies: [movie], next: this.table[idx] };
        this.table[idx] = newNode;
    }

    reindex(mode) {
        this.table = new Array(this.size).fill(null);
        this.clear();

        if (mode === 'actor') {
            MOCK_MOVIES.forEach(m => {
                m.actors.forEach(a => this.populate(a, m));
            });
        } else {
            MOCK_MOVIES.forEach(m => {
                m.genres.forEach(g => this.populate(g, m));
            });
        }
        this.renderTable();
    }

    renderTable() {
        this.clear();
        // Since we have 5000 movies, the lists are huge.
        // We will make the container very tall.
        this.container.style.height = `${this.size * 80 + 100}px`;
        const bucketHeight = 80;

        for (let i = 0; i < this.size; i++) {
            const bucket = document.createElement('div');
            Object.assign(bucket.style, {
                position: 'absolute', left: '20px', top: `${i * bucketHeight + 20}px`,
                width: '50px', height: '50px', border: '1px solid var(--glass-border)',
                background: 'rgba(255,255,255,0.05)', color: 'var(--text-dim)',
                display: 'flex', justifyContent: 'center', alignItems: 'center', borderRadius: '4px',
                fontSize: '1.2rem'
            });
            bucket.innerText = i;
            bucket.id = `bucket-${i}`;
            this.container.appendChild(bucket);

            // Count
            let count = 0;
            let distinctKeys = 0;
            let curr = this.table[i];
            while (curr) { count += curr.movies.length; distinctKeys++; curr = curr.next; }

            if (count > 0) {
                const ind = document.createElement('div');
                ind.innerHTML = `<span style="color:white">${distinctKeys} unique keys</span><br><small>${count} records</small>`;
                Object.assign(ind.style, { position: 'absolute', left: '80px', top: `${i * bucketHeight + 25}px`, fontSize: '0.8rem', color: '#666' });
                this.container.appendChild(ind);
            }
        }
    }

    search() {
        this.reindex('actor');
        const input = document.getElementById('hash-input');
        this.performSearch(input.value.trim());
    }

    searchGenre() {
        this.reindex('genre');
        const input = document.getElementById('genre-select');
        this.performSearch(input.value);
    }

    async performSearch(key) {
        if (!key) return;
        const index = this.hash(key); // uses toLowerCase

        // Highlight Bucket
        const bucket = document.getElementById(`bucket-${index}`);
        if (bucket) {
            bucket.style.borderColor = 'var(--secondary)';
            bucket.style.background = 'rgba(255,0,85,0.2)';
            bucket.scrollIntoView({ behavior: "smooth", block: "center" });
        }

        // Find Node
        let curr = this.table[index];
        let found = null;
        while (curr) {
            if (curr.key.toLowerCase() === key.toLowerCase()) { found = curr; break; }
            curr = curr.next;
        }

        // Remove old result nodes
        document.querySelectorAll('.node-hash-result').forEach(e => e.remove());

        if (found) {
            const display = document.createElement('div');
            display.className = 'node-hash-result';
            Object.assign(display.style, {
                position: 'absolute', left: '250px', top: `${index * 80 + 20}px`,
                width: '300px', padding: '15px', background: 'var(--bg-panel)',
                border: '1px solid var(--secondary)',
                color: 'white', borderRadius: '8px', zIndex: 100,
                boxShadow: '0 5px 20px black'
            });

            const movieList = found.movies.slice(0, 10).map(m => `<li>${m.title} <span style="color:#666">(${m.year})</span></li>`).join('');
            const moreCount = found.movies.length - 10;

            display.innerHTML = `<h3 style="color:var(--primary); margin-bottom:5px;">${found.key}</h3>
                                 <p style="margin-bottom:10px;">Found in ${found.movies.length} movies:</p>
                                 <ul style="padding-left:20px; font-size:0.9rem; color:#ccc;">${movieList}</ul>
                                 ${moreCount > 0 ? `<p style="margin-top:5px; font-style:italic;">...and ${moreCount} more</p>` : ''}`;

            this.container.appendChild(display);
            if (typeof soundManager !== 'undefined') soundManager.playSuccess();
        } else {
            alert(`"${key}" not found in current index.`);
        }
    }
}

const hashVisualizer = new HashVisualizer();
