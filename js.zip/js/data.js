// Data Generator for 5000 Movies

const ADJECTIVES = ["Dark", "Lost", "Fast", "Silent", "Eternal", "Brave", "Last", "First", "Hidden", "Broken", "Rising", "Fallen", "Secret", "Crimson", "Golden", "Iron", "Steel", "Savage", "Frozen", "Burning", "Infinite", "Beyond", "Galactic", "Cyber", "Neon", "Velvet"];
const NOUNS = ["Knight", "World", "Star", "Dream", "Legend", "Warrior", "Shadow", "King", "Queen", "Storm", "River", "Ocean", "Sky", "City", "Empire", "Titan", "Ghost", "Spirit", "Dragon", "Phoenix", "Wolf", "Eagle", "Voyager", "Matrix", "Dimension", "Horizon"];
const DIRECTORS = ["Christopher Nolan", "Steven Spielberg", "Martin Scorsese", "Quentin Tarantino", "James Cameron", "Ridley Scott", "David Fincher", "Stanley Kubrick", "Alfred Hitchcock", "Tim Burton", "George Lucas", "Peter Jackson", "Greta Gerwig", "Denis Villeneuve", "Wes Anderson"];
const ACTORS_POOL = [
    "Leonardo DiCaprio", "Brad Pitt", "Tom Hanks", "Robert De Niro", "Al Pacino", "Meryl Streep", "Denzel Washington", "Tom Cruise",
    "Johnny Depp", "Will Smith", "Julia Roberts", "Angelina Jolie", "Scarlett Johansson", "Jennifer Lawrence", "Emma Stone",
    "Chris Hemsworth", "Robert Downey Jr.", "Chris Evans", "Mark Ruffalo", "Samuel L. Jackson", "Morgan Freeman", "Matt Damon",
    "Christian Bale", "Heath Ledger", "Joaquin Phoenix", "Keanu Reeves", "Harrison Ford", "Carrie Fisher", "Mark Hamill",
    "Natalie Portman", "Anne Hathaway", "Matthew McConaughey", "Jessica Chastain", "Ryan Gosling", "Emma Watson"
];
const GENRES = ["Action", "Adventure", "Sci-Fi", "Drama", "Crime", "Thriller", "Horror", "Comedy", "Romance", "Fantasy", "Animation", "Mystery"];

function generateDataset(count) {
    const movies = [];
    const usedTitles = new Set();

    // Add some known real movies first (for demo feel)
    const REAL_MOVIES = [
        { title: "Inception", year: 2010, director: "Christopher Nolan", rating: 8.8, actors: ["Leonardo DiCaprio", "Joseph Gordon-Levitt"], genres: ["Sci-Fi", "Action"] },
        { title: "The Dark Knight", year: 2008, director: "Christopher Nolan", rating: 9.0, actors: ["Christian Bale", "Heath Ledger"], genres: ["Action", "Crime"] },
        { title: "Interstellar", year: 2014, director: "Christopher Nolan", rating: 8.6, actors: ["Matthew McConaughey", "Anne Hathaway"], genres: ["Sci-Fi", "Adventure"] },
        { title: "Pulp Fiction", year: 1994, director: "Quentin Tarantino", rating: 8.9, actors: ["John Travolta", "Uma Thurman"], genres: ["Crime", "Drama"] },
        { title: "The Matrix", year: 1999, director: "Lana Wachowski", rating: 8.7, actors: ["Keanu Reeves", "Laurence Fishburne"], genres: ["Sci-Fi", "Action"] },
        { title: "Avengers: Endgame", year: 2019, director: "Anthony Russo", rating: 8.4, actors: ["Robert Downey Jr.", "Chris Evans"], genres: ["Action", "Sci-Fi"] }
    ];

    REAL_MOVIES.forEach(m => {
        movies.push(m);
        usedTitles.add(m.title);
    });

    for (let i = movies.length; i < count; i++) {
        let title;
        let attempts = 0;
        do {
            const adj = ADJECTIVES[Math.floor(Math.random() * ADJECTIVES.length)];
            const noun = NOUNS[Math.floor(Math.random() * NOUNS.length)];
            const suffix = Math.random() > 0.8 ? " " + (Math.floor(Math.random() * 5) + 2) : ""; // Sequel Numbers
            title = `The ${adj} ${noun}${suffix}`;
            attempts++;
        } while (usedTitles.has(title) && attempts < 10);

        if (usedTitles.has(title)) title += ` ${i}`; // Fallback unique
        usedTitles.add(title);

        // Random Attributes
        const year = 1970 + Math.floor(Math.random() * 54);
        const director = DIRECTORS[Math.floor(Math.random() * DIRECTORS.length)];
        const rating = (Math.random() * 5 + 4).toFixed(1); // 4.0 - 9.0

        // Pick 2-3 Actors
        const movieActors = [];
        const numActors = Math.floor(Math.random() * 2) + 2;
        for (let a = 0; a < numActors; a++) {
            const act = ACTORS_POOL[Math.floor(Math.random() * ACTORS_POOL.length)];
            if (!movieActors.includes(act)) movieActors.push(act);
        }

        // Pick 1-2 Genres
        const movieGenres = [];
        const numGenres = Math.floor(Math.random() * 2) + 1;
        for (let g = 0; g < numGenres; g++) {
            const gen = GENRES[Math.floor(Math.random() * GENRES.length)];
            if (!movieGenres.includes(gen)) movieGenres.push(gen);
        }

        movies.push({
            title: title,
            year: year,
            director: director,
            rating: parseFloat(rating),
            actors: movieActors,
            genres: movieGenres
        });
    }

    return movies;
}

const MOCK_MOVIES = generateDataset(5000);
console.log(`DATAJS: Generated ${MOCK_MOVIES.length} movies.`);
